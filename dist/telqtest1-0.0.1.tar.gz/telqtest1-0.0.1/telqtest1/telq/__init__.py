


class TelQ():

    def hello():
        return 'Hey there !!'